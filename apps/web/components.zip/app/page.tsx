import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import HeroSection from '@/components/home/HeroSection'
import StatementSection from '@/components/home/StatementSection'
import ProductsSection from '@/components/home/ProductsSection'
import ProblemSection from '@/components/home/ProblemSection'
import ValuesSection from '@/components/home/ValuesSection'
import StatsSection from '@/components/home/StatsSection'
import HowItWorksSection from '@/components/home/HowItWorksSection'
import TestimonialsSection from '@/components/home/TestimonialsSection'
import ClosingSection from '@/components/home/ClosingSection'
import SeasonalDivider from '@/components/ui/SeasonalDivider'

export default function Home() {
  return (
    <>
      <a href="#main-content" className="skip-to-main">
        Skip to main content
      </a>
      <Navbar />
      <main id="main-content">
        <HeroSection />
        <StatementSection />
        <ProductsSection />
        <div style={{ padding: '0 24px' }}>
          <SeasonalDivider />
        </div>
        <ProblemSection />
        <ValuesSection />
        <StatsSection />
        <HowItWorksSection />
        <div style={{ padding: '0 24px' }}>
          <SeasonalDivider />
        </div>
        <TestimonialsSection />
        <ClosingSection />
      </main>
      <Footer />
    </>
  )
}
